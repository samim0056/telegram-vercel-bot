# ⚡ Telegram Python Bot - Vercel 24/7 Serverless

Modern, colorful web dashboard and serverless Telegram Python bot runner designed for **100% Free 24/7 deployment on Vercel**.

---

## 🌟 Key Features

1. **24/7 Zero-Downtime Serverless Bot**:
   - Uses Telegram Webhooks (no infinite polling loop that freezes or sleeps).
   - Instantly handles `/start`, `/help`, `/ping`, `/status`, `/echo`, and custom messages.

2. **Ultra-Modern & Colorful Web Dashboard**:
   - Cyberpunk / Neon Glassmorphism design with glowing gradients.
   - Built-in credentials manager (saves Bot Token locally).
   - One-Click **Set Webhook**, **Check Status**, and **Delete Webhook**.
   - **Send Test Message** directly to any Telegram chat ID from browser.
   - Real-time Webhook Activity and Event logs.

3. **Smart Requirements Manager**:
   - Automatically downloads and installs dependencies via `requirements.txt` on Vercel.
   - Built-in **Auto-Detect Python Code Scanner**: Paste any Python bot script, and it detects all imported libraries (`bs4`, `firebase-admin`, `requests`, `pyotp`, etc.) and adds them to requirements!
   - 1-Click **Download requirements.txt** button.
   - 1-Click **Download Project Zip** button for instant GitHub repo upload.

4. **In-Browser Bot Simulator**:
   - Test bot commands and interactions directly in the web UI.

---

## 🚀 Quick Start (Local Run on Termux/PC)

To run and preview the dashboard locally:
```bash
cd telegram-vercel-bot
python3 api/index.py
```
Then open your browser at:
`http://localhost:8080`

---

## ☁️ How to Deploy to Vercel (100% Free 24/7)

### Step 1: Push to GitHub
1. Create a new GitHub repository (e.g. `my-telegram-bot`).
2. Upload the contents of this folder (`vercel.json`, `requirements.txt`, `api/index.py`).

### Step 2: Import on Vercel
1. Go to [Vercel.com](https://vercel.com) and log in.
2. Click **Add New... → Project** and select your GitHub repo.
3. In **Environment Variables** (optional):
   - Add `BOT_TOKEN` = `your_bot_token_from_botfather`
4. Click **Deploy**!

### Step 3: Activate 24/7 Webhook
1. Copy your Vercel deployment URL (e.g., `https://my-telegram-bot.vercel.app`).
2. Open that URL in your browser to see your Colorful Dashboard.
3. Enter your Bot Token and click **🔗 Set 24/7 Webhook**.
4. That's it! Your bot is now live 24/7! 🎉
