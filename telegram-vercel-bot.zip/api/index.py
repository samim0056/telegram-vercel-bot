import os
import sys
import json
import time
import re
import ast
import zipfile
import io
from datetime import datetime
from urllib.parse import parse_qs, urlparse

# Standard library module names to ignore during dependency scanning
STDLIB_MODULES = {
    'abc', 'aifc', 'argparse', 'array', 'ast', 'asynchat', 'asyncio', 'asyncore',
    'atexit', 'audioop', 'base64', 'bdb', 'binascii', 'binhex', 'bisect', 'builtins',
    'bz2', 'calendar', 'cgi', 'cgitb', 'chunk', 'cmath', 'cmd', 'code', 'codecs',
    'codeop', 'collections', 'colorsys', 'compileall', 'concurrent', 'configparser',
    'contextlib', 'contextvars', 'copy', 'copyreg', 'crypt', 'csv', 'ctypes',
    'curses', 'dataclasses', 'datetime', 'dbm', 'decimal', 'difflib', 'dis',
    'distutils', 'doctest', 'email', 'encodings', 'enum', 'errno', 'faulthandler',
    'fcntl', 'filecmp', 'fileinput', 'fnmatch', 'fractions', 'ftplib', 'functools',
    'gc', 'getopt', 'getpass', 'gettext', 'glob', 'graphlib', 'grp', 'gzip',
    'hashlib', 'heapq', 'hmac', 'html', 'http', 'imaplib', 'imghdr', 'imp',
    'importlib', 'inspect', 'io', 'ipaddress', 'itertools', 'json', 'keyword',
    'linecache', 'locale', 'logging', 'lzma', 'mailbox', 'mailcap', 'marshal',
    'math', 'mimetypes', 'mmap', 'modulefinder', 'msilib', 'msvcrt', 'multiprocessing',
    'netrc', 'nis', 'nntplib', 'numbers', 'operator', 'optparse', 'os', 'ossaudiodev',
    'pathlib', 'pdb', 'pickle', 'pickletools', 'pipes', 'pkgutil', 'platform',
    'plistlib', 'poplib', 'posix', 'posixpath', 'pprint', 'profile', 'pstats',
    'pty', 'pwd', 'py_compile', 'pyclbr', 'pydoc', 'queue', 'quopri', 'random',
    're', 'readline', 'reprlib', 'resource', 'rlcompleter', 'runpy', 'sched',
    'secrets', 'select', 'selectors', 'shelve', 'shlex', 'shutil', 'signal',
    'site', 'smtpd', 'smtplib', 'sndhdr', 'socket', 'socketserver', 'spwd',
    'sqlite3', 'ssl', 'stat', 'statistics', 'string', 'stringprep', 'struct',
    'subprocess', 'sunau', 'symbol', 'symtable', 'sys', 'sysconfig', 'syslog',
    'tabnanny', 'tarfile', 'telnetlib', 'tempfile', 'termios', 'test', 'textwrap',
    'threading', 'time', 'timeit', 'tkinter', 'token', 'tokenize', 'trace',
    'traceback', 'tracemalloc', 'tty', 'turtle', 'turtledemo', 'types', 'typing',
    'unicodedata', 'unittest', 'urllib', 'uu', 'uuid', 'venv', 'warnings',
    'wave', 'weakref', 'webbrowser', 'winreg', 'winsound', 'wsgiref', 'xdrlib',
    'xml', 'xmlrpc', 'zipapp', 'zipfile', 'zipimport', 'zlib', '_thread'
}

# Mapping common import names to PyPI package names
IMPORT_TO_PYPI = {
    'bs4': 'beautifulsoup4',
    'firebase_admin': 'firebase-admin',
    'pyotp': 'pyotp',
    'requests': 'requests',
    'telebot': 'pyTelegramBotAPI',
    'telegram': 'python-telegram-bot',
    'aiogram': 'aiogram',
    'PIL': 'Pillow',
    'cv2': 'opencv-python',
    'dotenv': 'python-dotenv',
    'yaml': 'PyYAML',
    'flask': 'Flask',
    'fastapi': 'fastapi',
    'uvicorn': 'uvicorn',
    'sqlalchemy': 'SQLAlchemy',
    'jwt': 'PyJWT',
    'dateutil': 'python-dateutil',
    'crypto': 'pycryptodome',
    'Crypto': 'pycryptodome',
    'dns': 'dnspython',
    'pymongo': 'pymongo',
    'redis': 'redis',
    'httpx': 'httpx',
    'aiohttp': 'aiohttp',
    'pandas': 'pandas',
    'numpy': 'numpy'
}

# In-memory recent events log (for serverless instances)
ACTIVITY_LOGS = []
START_TIME = time.time()

def add_log(event_type, message, status="info"):
    entry = {
        "time": datetime.utcnow().strftime("%H:%M:%S UTC"),
        "type": event_type,
        "message": message,
        "status": status
    }
    ACTIVITY_LOGS.insert(0, entry)
    if len(ACTIVITY_LOGS) > 30:
        ACTIVITY_LOGS.pop()

# Try importing Flask
try:
    from flask import Flask, request, jsonify, send_file, Response
    FLASK_AVAILABLE = True
except ImportError:
    FLASK_AVAILABLE = False

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


def scan_python_code(code_str):
    """Parses python code and extracts non-standard dependencies mapped to PyPI."""
    imported_modules = set()
    try:
        tree = ast.parse(code_str)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root_pkg = alias.name.split('.')[0]
                    imported_modules.add(root_pkg)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    root_pkg = node.module.split('.')[0]
                    imported_modules.add(root_pkg)
    except Exception:
        # Fallback to regex in case of syntax error in incomplete pasted code
        regex_imports = re.findall(r'^(?:import|from)\s+([a-zA-Z0-9_]+)', code_str, re.MULTILINE)
        for pkg in regex_imports:
            imported_modules.add(pkg)

    # Filter out standard library
    external = imported_modules - STDLIB_MODULES
    packages = []
    for mod in sorted(list(external)):
        pypi_name = IMPORT_TO_PYPI.get(mod, mod)
        packages.append(pypi_name)
    return sorted(list(set(packages)))


def handle_telegram_update(bot_token, update_data):
    """Processes incoming Telegram Webhook updates and returns response text."""
    if not bot_token or not REQUESTS_AVAILABLE:
        return "Missing bot token or requests library", 400

    message = update_data.get("message") or update_data.get("edited_message")
    callback = update_data.get("callback_query")

    chat_id = None
    reply_text = ""
    user_name = "User"

    if message:
        chat_id = message.get("chat", {}).get("id")
        user_name = message.get("from", {}).get("first_name", "Friend")
        text = (message.get("text") or "").strip()

        add_log("Telegram Message", f"From {user_name} (ID: {chat_id}): '{text}'", "success")

        if text.startswith("/start"):
            reply_text = (
                f"✨ <b>Hello, {user_name}!</b>\n\n"
                f"🚀 <i>Your Python Telegram Bot is running 24/7 on Vercel Serverless!</i>\n\n"
                f"⚡ <b>Commands Available:</b>\n"
                f"• /help - Show commands guide\n"
                f"• /ping - Check bot response latency\n"
                f"• /status - Serverless runtime info\n"
                f"• /echo &lt;text&gt; - Repeat your message\n\n"
                f"🎨 <i>Controlled via your Modern Vercel Dashboard.</i>"
            )
        elif text.startswith("/ping"):
            reply_text = "🏓 <b>Pong!</b> Bot response is active and instant via Vercel Webhook ⚡"
        elif text.startswith("/status"):
            uptime_secs = int(time.time() - START_TIME)
            reply_text = (
                f"📊 <b>Bot Serverless Status</b>\n"
                f"• <b>Platform:</b> Vercel Cloud Serverless\n"
                f"• <b>Python:</b> {sys.version.split()[0]}\n"
                f"• <b>Method:</b> Telegram Webhook (Zero Downtime)\n"
                f"• <b>Instance Uptime:</b> {uptime_secs}s\n"
                f"• <b>Cost:</b> 100% Free Forever"
            )
        elif text.startswith("/help"):
            reply_text = (
                f"📖 <b>Bot Help & Commands</b>\n\n"
                f"• <code>/start</code> - Welcome banner\n"
                f"• <code>/ping</code> - Check latency\n"
                f"• <code>/status</code> - Vercel runtime stats\n"
                f"• <code>/echo [msg]</code> - Echoes message back\n\n"
                f"💡 <i>Tip: You can modify handlers in api/index.py anytime!</i>"
            )
        elif text.startswith("/echo"):
            content = text[5:].strip() or "Please specify text to echo!"
            reply_text = f"🗣️ <b>Echo:</b> {content}"
        else:
            reply_text = (
                f"🤖 Received your message: <i>\"{text}\"</i>\n\n"
                f"Type /help to see all available commands!"
            )

    elif callback:
        chat_id = callback.get("message", {}).get("chat", {}).get("id")
        data = callback.get("data", "")
        add_log("Telegram Callback", f"Callback: {data}", "info")
        reply_text = f"🔘 Button clicked: {data}"

    if chat_id and reply_text:
        send_url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        payload = {
            "chat_id": chat_id,
            "text": reply_text,
            "parse_mode": "HTML"
        }
        try:
            requests.post(send_url, json=payload, timeout=8)
            return "OK", 200
        except Exception as e:
            add_log("Telegram Error", str(e), "error")
            return f"Telegram API error: {str(e)}", 500

    return "Ignored or no text", 200


# HTML Dashboard Template embedded
DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Telegram Python Bot - Vercel 24/7 Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-dark: #0a0b14;
      --bg-card: rgba(18, 20, 38, 0.75);
      --bg-card-border: rgba(139, 92, 246, 0.25);
      --primary: #8b5cf6;
      --primary-glow: rgba(139, 92, 246, 0.5);
      --secondary: #06b6d4;
      --accent-pink: #ec4899;
      --accent-green: #10b981;
      --accent-amber: #f59e0b;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --radius-lg: 20px;
      --radius-md: 12px;
      --font-code: 'JetBrains Mono', monospace;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background-color: var(--bg-dark);
      color: var(--text-main);
      min-height: 100vh;
      overflow-x: hidden;
      position: relative;
      background-image: 
        radial-gradient(circle at 10% 20%, rgba(139, 92, 246, 0.18) 0%, transparent 40%),
        radial-gradient(circle at 90% 10%, rgba(6, 182, 212, 0.18) 0%, transparent 40%),
        radial-gradient(circle at 50% 85%, rgba(236, 72, 153, 0.15) 0%, transparent 45%);
      background-attachment: fixed;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 30px 20px 80px;
    }

    /* HEADER */
    header {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      gap: 20px;
      margin-bottom: 35px;
      padding-bottom: 25px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .logo-badge {
      width: 52px;
      height: 52px;
      border-radius: 16px;
      background: linear-gradient(135deg, #8b5cf6, #06b6d4);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 26px;
      box-shadow: 0 0 25px var(--primary-glow);
    }

    .brand h1 {
      font-size: 24px;
      font-weight: 800;
      background: linear-gradient(90deg, #ffffff, #c4b5fd, #67e8f9);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .brand p {
      font-size: 13px;
      color: var(--text-muted);
    }

    .status-badge {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: rgba(16, 185, 129, 0.12);
      border: 1px solid rgba(16, 185, 129, 0.35);
      color: #34d399;
      padding: 8px 16px;
      border-radius: 999px;
      font-size: 13px;
      font-weight: 600;
    }

    .pulse-dot {
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: #10b981;
      box-shadow: 0 0 10px #10b981;
      animation: pulse 1.8s infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; transform: scale(1); }
      50% { opacity: 0.4; transform: scale(1.3); }
    }

    /* GRID & CARDS */
    .grid-2 {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
      gap: 25px;
      margin-bottom: 30px;
    }

    .card {
      background: var(--bg-card);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid var(--bg-card-border);
      border-radius: var(--radius-lg);
      padding: 26px;
      box-shadow: 0 12px 35px rgba(0, 0, 0, 0.35);
      position: relative;
      overflow: hidden;
      transition: transform 0.25s ease, border-color 0.25s ease;
    }

    .card:hover {
      border-color: rgba(139, 92, 246, 0.45);
      transform: translateY(-2px);
    }

    .card-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 20px;
    }

    .card-title {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 18px;
      font-weight: 700;
      color: #ffffff;
    }

    .card-icon {
      font-size: 20px;
    }

    /* FORMS & INPUTS */
    .form-group {
      margin-bottom: 18px;
    }

    .form-label {
      display: block;
      font-size: 13px;
      font-weight: 600;
      color: #cbd5e1;
      margin-bottom: 8px;
    }

    .form-input {
      width: 100%;
      background: rgba(10, 11, 22, 0.85);
      border: 1px solid rgba(148, 163, 184, 0.2);
      border-radius: var(--radius-md);
      padding: 12px 16px;
      color: #ffffff;
      font-size: 14px;
      outline: none;
      transition: border-color 0.2s, box-shadow 0.2s;
      font-family: var(--font-code);
    }

    .form-input:focus {
      border-color: var(--primary);
      box-shadow: 0 0 12px var(--primary-glow);
    }

    .form-textarea {
      min-height: 120px;
      resize: vertical;
    }

    /* BUTTONS */
    .btn-group {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 20px;
    }

    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 12px 20px;
      border-radius: var(--radius-md);
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      border: none;
      outline: none;
      transition: all 0.2s ease;
      text-decoration: none;
    }

    .btn-primary {
      background: linear-gradient(135deg, #8b5cf6, #6366f1);
      color: #ffffff;
      box-shadow: 0 4px 18px rgba(99, 102, 241, 0.35);
    }

    .btn-primary:hover {
      box-shadow: 0 6px 25px rgba(99, 102, 241, 0.6);
      transform: translateY(-1px);
    }

    .btn-secondary {
      background: linear-gradient(135deg, #06b6d4, #0284c7);
      color: #ffffff;
      box-shadow: 0 4px 18px rgba(6, 182, 212, 0.3);
    }

    .btn-secondary:hover {
      box-shadow: 0 6px 25px rgba(6, 182, 212, 0.5);
      transform: translateY(-1px);
    }

    .btn-pink {
      background: linear-gradient(135deg, #ec4899, #d946ef);
      color: #ffffff;
      box-shadow: 0 4px 18px rgba(236, 72, 153, 0.3);
    }

    .btn-pink:hover {
      box-shadow: 0 6px 25px rgba(236, 72, 153, 0.5);
      transform: translateY(-1px);
    }

    .btn-outline {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(255, 255, 255, 0.15);
      color: #e2e8f0;
    }

    .btn-outline:hover {
      background: rgba(255, 255, 255, 0.12);
      border-color: rgba(255, 255, 255, 0.3);
    }

    .btn-sm {
      padding: 7px 12px;
      font-size: 12px;
      border-radius: 8px;
    }

    /* CODE BOX & REQUIREMENTS */
    .code-box {
      background: #070810;
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: var(--radius-md);
      padding: 16px;
      font-family: var(--font-code);
      font-size: 13px;
      color: #38bdf8;
      max-height: 200px;
      overflow-y: auto;
      white-space: pre-wrap;
      word-break: break-all;
    }

    .tag-container {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 12px;
    }

    .tag {
      background: rgba(139, 92, 246, 0.15);
      border: 1px solid rgba(139, 92, 246, 0.3);
      color: #c4b5fd;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 12px;
      font-family: var(--font-code);
    }

    /* ACTIVITY LOGS */
    .log-list {
      list-style: none;
      max-height: 250px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .log-item {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 10px 14px;
      background: rgba(15, 17, 30, 0.85);
      border-radius: 10px;
      border-left: 3px solid var(--primary);
      font-size: 13px;
    }

    .log-item.success { border-left-color: var(--accent-green); }
    .log-item.error { border-left-color: #ef4444; }
    .log-item.info { border-left-color: var(--secondary); }

    .log-time {
      color: var(--text-muted);
      font-size: 11px;
      font-family: var(--font-code);
      min-width: 70px;
    }

    .log-content {
      color: #e2e8f0;
      word-break: break-word;
    }

    /* TOAST */
    #toast {
      position: fixed;
      bottom: 25px;
      right: 25px;
      padding: 14px 22px;
      border-radius: 12px;
      background: rgba(18, 20, 38, 0.95);
      backdrop-filter: blur(15px);
      border: 1px solid var(--primary);
      color: #ffffff;
      font-size: 14px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
      z-index: 9999;
      opacity: 0;
      transform: translateY(20px);
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      pointer-events: none;
    }

    #toast.show {
      opacity: 1;
      transform: translateY(0);
      pointer-events: auto;
    }

    /* TABS */
    .tabs {
      display: flex;
      gap: 10px;
      margin-bottom: 25px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      padding-bottom: 12px;
      overflow-x: auto;
    }

    .tab-btn {
      background: transparent;
      border: none;
      color: var(--text-muted);
      font-size: 14px;
      font-weight: 600;
      padding: 10px 18px;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.2s;
      white-space: nowrap;
    }

    .tab-btn:hover {
      color: #ffffff;
      background: rgba(255, 255, 255, 0.05);
    }

    .tab-btn.active {
      color: #ffffff;
      background: linear-gradient(135deg, rgba(139, 92, 246, 0.25), rgba(6, 182, 212, 0.2));
      border: 1px solid rgba(139, 92, 246, 0.4);
    }

    .tab-pane {
      display: none;
    }

    .tab-pane.active {
      display: block;
    }

    /* INFO CALLOUT */
    .callout {
      background: linear-gradient(90deg, rgba(139, 92, 246, 0.12), rgba(6, 182, 212, 0.08));
      border: 1px solid rgba(139, 92, 246, 0.3);
      border-radius: var(--radius-md);
      padding: 16px;
      margin-bottom: 20px;
      font-size: 13px;
      line-height: 1.6;
      color: #cbd5e1;
    }

    .callout strong {
      color: #67e8f9;
    }
  </style>
</head>
<body>

  <div class="container">
    <!-- HEADER -->
    <header>
      <div class="brand">
        <div class="logo-badge">⚡</div>
        <div>
          <h1>Telegram Bot Vercel 24/7</h1>
          <p>Serverless Python Webhook Runner & Requirements Manager</p>
        </div>
      </div>
      <div class="status-badge">
        <div class="pulse-dot"></div>
        <span id="systemStatus">Vercel Ready & Active</span>
      </div>
    </header>

    <!-- CALLOUT TIP -->
    <div class="callout">
      💡 <b>24/7 Free Hosting Rule:</b> Vercel par Telegram bot <b>Webhook</b> ke zariye chalta hai. Jab koi user bot ko message karta hai, Vercel turant instant response de kar 24/7 bina soye chalta hai. <b>Requirements.txt</b> Vercel deploy hote waqt automatically download & install kar leta hai!
    </div>

    <!-- TABS -->
    <div class="tabs">
      <button class="tab-btn active" onclick="switchTab('controller')">🚀 Webhook Controller</button>
      <button class="tab-btn" onclick="switchTab('requirements')">📦 Requirements Manager</button>
      <button class="tab-btn" onclick="switchTab('simulator')">💬 Bot Live Simulator</button>
      <button class="tab-btn" onclick="switchTab('deploy')">☁️ Vercel Deploy Guide</button>
    </div>

    <!-- TAB 1: CONTROLLER -->
    <div id="tab-controller" class="tab-pane active">
      <div class="grid-2">
        <!-- BOT SETTINGS -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <span class="card-icon">🔐</span>
              <span>Telegram Bot Credentials</span>
            </div>
            <button class="btn btn-outline btn-sm" onclick="saveCredentials()">💾 Save</button>
          </div>

          <div class="form-group">
            <label class="form-label">Telegram Bot Token (from @BotFather):</label>
            <input type="password" id="botToken" class="form-input" placeholder="e.g. 123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ">
          </div>

          <div class="form-group">
            <label class="form-label">Vercel App URL (or Local URL):</label>
            <input type="text" id="appUrl" class="form-input" placeholder="https://your-bot.vercel.app">
          </div>

          <div class="btn-group">
            <button class="btn btn-primary" onclick="setTelegramWebhook()">🔗 Set 24/7 Webhook</button>
            <button class="btn btn-secondary" onclick="checkWebhookInfo()">🔍 Check Status</button>
            <button class="btn btn-outline" onclick="deleteTelegramWebhook()">🗑️ Remove</button>
          </div>
        </div>

        <!-- TEST SENDER -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <span class="card-icon">📨</span>
              <span>Send Test Message</span>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Telegram Chat ID (Your User ID):</label>
            <input type="text" id="testChatId" class="form-input" placeholder="e.g. 7869079719">
          </div>

          <div class="form-group">
            <label class="form-label">Test Message Content:</label>
            <input type="text" id="testMsgText" class="form-input" value="🚀 Testing Telegram Bot 24/7 from Vercel!">
          </div>

          <div class="btn-group">
            <button class="btn btn-pink" onclick="sendTestMessage()">📤 Send Test to Telegram</button>
          </div>
        </div>
      </div>

      <!-- LIVE ACTIVITY LOG -->
      <div class="card">
        <div class="card-header">
          <div class="card-title">
            <span class="card-icon">⚡</span>
            <span>Real-time Activity & Webhook Events</span>
          </div>
          <button class="btn btn-outline btn-sm" onclick="fetchLogs()">🔄 Refresh</button>
        </div>
        <ul class="log-list" id="activityLogList">
          <li class="log-item info">
            <span class="log-time">Now</span>
            <span class="log-content">System initialized. Ready to receive Telegram Webhook updates.</span>
          </li>
        </ul>
      </div>
    </div>

    <!-- TAB 2: REQUIREMENTS MANAGER -->
    <div id="tab-requirements" class="tab-pane">
      <div class="grid-2">
        <!-- CURRENT REQUIREMENTS -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <span class="card-icon">📦</span>
              <span>Current requirements.txt</span>
            </div>
            <button class="btn btn-primary btn-sm" onclick="downloadRequirementsTxt()">⬇️ Download requirements.txt</button>
          </div>
          <div class="code-box" id="reqBox">Flask>=3.0.0
requests>=2.31.0
beautifulsoup4>=4.12.0
pyotp>=2.9.0</div>
          
          <div style="margin-top: 15px;">
            <p class="form-label">Vercel Auto-Install Features:</p>
            <div class="tag-container">
              <span class="tag">⚡ Auto-installed on git push</span>
              <span class="tag">☁️ Cloud pip caching</span>
              <span class="tag">🔒 Zero manual server setup</span>
            </div>
          </div>
        </div>

        <!-- CODE SCANNER -->
        <div class="card">
          <div class="card-header">
            <div class="card-title">
              <span class="card-icon">🔍</span>
              <span>Auto-Detect Requirements from Python Code</span>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Paste any Python bot code below to scan its imports:</label>
            <textarea id="scanCodeInput" class="form-input form-textarea" placeholder="Paste python bot code here... (e.g. import requests, bs4, pyotp, firebase_admin)"></textarea>
          </div>
          <div class="btn-group">
            <button class="btn btn-secondary" onclick="scanCodeDependencies()">🔎 Auto Scan & Add Packages</button>
            <button class="btn btn-outline" onclick="loadMyBotCode()">📂 Load my_bot.py</button>
          </div>
        </div>
      </div>
    </div>

    <!-- TAB 3: SIMULATOR -->
    <div id="tab-simulator" class="tab-pane">
      <div class="card" style="max-width: 700px; margin: 0 auto;">
        <div class="card-header">
          <div class="card-title">
            <span class="card-icon">💬</span>
            <span>In-Browser Webhook Bot Simulator</span>
          </div>
        </div>
        <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 15px;">
          Test your bot logic directly in browser without sending messages to Telegram first:
        </p>

        <div class="code-box" id="simulatorChat" style="min-height: 200px; max-height: 300px; margin-bottom: 15px; color: #f1f5f9;">
Bot: 🤖 Hi! I am your Vercel Webhook bot. Send /start, /ping, /status, or /echo hello!
        </div>

        <div style="display: flex; gap: 10px;">
          <input type="text" id="simInput" class="form-input" placeholder="Type /start or message..." onkeydown="if(event.key==='Enter') runSimMessage()">
          <button class="btn btn-primary" onclick="runSimMessage()">Send</button>
        </div>
      </div>
    </div>

    <!-- TAB 4: DEPLOY GUIDE -->
    <div id="tab-deploy" class="tab-pane">
      <div class="card">
        <div class="card-header">
          <div class="card-title">
            <span class="card-icon">☁️</span>
            <span>How to Deploy to Vercel in 2 Minutes</span>
          </div>
          <button class="btn btn-pink btn-sm" onclick="downloadFullProjectZip()">🎁 Download Full Project Zip</button>
        </div>

        <div style="display: flex; flex-direction: column; gap: 20px; font-size: 14px; line-height: 1.7; color: #cbd5e1;">
          <div>
            <strong style="color: #67e8f9;">Step 1: GitHub Repository Banayein</strong>
            <p>GitHub par ek new repository banayein (e.g. <code>my-telegram-bot</code>) aur is project folder ke files upload karein.</p>
          </div>

          <div>
            <strong style="color: #67e8f9;">Step 2: Vercel Par Connect Karein</strong>
            <p><a href="https://vercel.com" target="_blank" style="color: #8b5cf6;">Vercel.com</a> par login karein, <b>Add New... → Project</b> click karein, aur apni GitHub repo select karein.</p>
          </div>

          <div>
            <strong style="color: #67e8f9;">Step 3: Environment Variable Set Karein (Optional)</strong>
            <p>Vercel project settings me <code>BOT_TOKEN</code> add karein (ya website dashboard me token enter karein).</p>
          </div>

          <div>
            <strong style="color: #67e8f9;">Step 4: Deploy & Webhook Activate</strong>
            <p>Deploy hone ke baad Vercel aapko ek URL dega (jaise <code>https://my-bot.vercel.app</code>). Dashboard me wo URL paste karke <b>"Set 24/7 Webhook"</b> button dabayein! Bot 24/7 live ho jayega!</p>
          </div>
        </div>
      </div>
    </div>

  </div>

  <!-- TOAST NOTIFICATION -->
  <div id="toast">Notification message</div>

  <script>
    // Tab switching
    function switchTab(tabId) {
      document.querySelectorAll('.tab-pane').forEach(el => el.classList.remove('active'));
      document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
      document.getElementById('tab-' + tabId).classList.add('active');
      event.target.classList.add('active');
    }

    function showToast(msg) {
      const t = document.getElementById('toast');
      t.innerText = msg;
      t.classList.add('show');
      setTimeout(() => t.classList.remove('show'), 3500);
    }

    // Auto-fill URL & saved Token
    window.addEventListener('DOMContentLoaded', () => {
      const savedToken = localStorage.getItem('tg_bot_token');
      if (savedToken) document.getElementById('botToken').value = savedToken;
      const savedUrl = localStorage.getItem('tg_app_url');
      if (savedUrl) {
        document.getElementById('appUrl').value = savedUrl;
      } else {
        document.getElementById('appUrl').value = window.location.origin;
      }
      fetchLogs();
    });

    function saveCredentials() {
      const token = document.getElementById('botToken').value.trim();
      const url = document.getElementById('appUrl').value.trim();
      if (token) localStorage.setItem('tg_bot_token', token);
      if (url) localStorage.setItem('tg_app_url', url);
      showToast('✅ Credentials saved locally!');
    }

    async function setTelegramWebhook() {
      const token = document.getElementById('botToken').value.trim();
      const url = document.getElementById('appUrl').value.trim();
      if (!token) { showToast('⚠️ Please enter Bot Token first!'); return; }
      if (!url) { showToast('⚠️ Please enter App URL!'); return; }
      saveCredentials();

      const webhookUrl = url.replace(/\\/+$/, '') + '/api/webhook';
      try {
        const res = await fetch('/api/set_webhook', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bot_token: token, webhook_url: webhookUrl })
        });
        const data = await res.json();
        if (data.ok) {
          showToast('🚀 Webhook Successfully Activated! Bot is 24/7 Online!');
        } else {
          showToast('❌ Telegram Error: ' + (data.description || 'Failed'));
        }
        fetchLogs();
      } catch (err) {
        showToast('❌ Error: ' + err.message);
      }
    }

    async function checkWebhookInfo() {
      const token = document.getElementById('botToken').value.trim();
      if (!token) { showToast('⚠️ Please enter Bot Token first!'); return; }
      try {
        const res = await fetch('/api/webhook_info', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bot_token: token })
        });
        const data = await res.json();
        if (data.ok) {
          const info = data.result;
          alert(`📡 Telegram Webhook Status:\\n\\nURL: ${info.url || 'Not Set'}\\nPending Updates: ${info.pending_update_count}\\nLast Error: ${info.last_error_message || 'None'}`);
        } else {
          showToast('❌ ' + data.description);
        }
      } catch (err) {
        showToast('❌ Error: ' + err.message);
      }
    }

    async function deleteTelegramWebhook() {
      const token = document.getElementById('botToken').value.trim();
      if (!token) { showToast('⚠️ Please enter Bot Token first!'); return; }
      if (!confirm('Are you sure you want to remove the webhook?')) return;
      try {
        const res = await fetch('/api/delete_webhook', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bot_token: token })
        });
        const data = await res.json();
        if (data.ok) {
          showToast('🗑️ Webhook removed successfully.');
        } else {
          showToast('❌ ' + data.description);
        }
        fetchLogs();
      } catch (err) {
        showToast('❌ Error: ' + err.message);
      }
    }

    async function sendTestMessage() {
      const token = document.getElementById('botToken').value.trim();
      const chatId = document.getElementById('testChatId').value.trim();
      const text = document.getElementById('testMsgText').value.trim();
      if (!token || !chatId || !text) {
        showToast('⚠️ Please fill Token, Chat ID, and Message!');
        return;
      }
      try {
        const res = await fetch('/api/send_test', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ bot_token: token, chat_id: chatId, text: text })
        });
        const data = await res.json();
        if (data.ok) {
          showToast('✅ Test message sent to Telegram successfully!');
        } else {
          showToast('❌ ' + (data.description || 'Failed to send'));
        }
        fetchLogs();
      } catch (err) {
        showToast('❌ Error: ' + err.message);
      }
    }

    async function fetchLogs() {
      try {
        const res = await fetch('/api/status');
        const data = await res.json();
        const list = document.getElementById('activityLogList');
        if (data.logs && data.logs.length > 0) {
          list.innerHTML = data.logs.map(log => `
            <li class="log-item ${log.status}">
              <span class="log-time">${log.time}</span>
              <span class="log-content"><b>[${log.type}]</b> ${log.message}</span>
            </li>
          `).join('');
        }
      } catch (e) {}
    }

    function downloadRequirementsTxt() {
      const content = document.getElementById('reqBox').innerText;
      const blob = new Blob([content], { type: 'text/plain' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'requirements.txt';
      a.click();
      showToast('📥 requirements.txt downloaded!');
    }

    async function scanCodeDependencies() {
      const code = document.getElementById('scanCodeInput').value;
      if (!code.trim()) { showToast('⚠️ Paste some code to scan!'); return; }
      try {
        const res = await fetch('/api/scan_requirements', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code: code })
        });
        const data = await res.json();
        if (data.packages && data.packages.length > 0) {
          const reqs = ['Flask>=3.0.0', ...data.packages.map(p => `${p}`)].join('\\n');
          document.getElementById('reqBox').innerText = reqs;
          showToast(`✨ Detected & Added ${data.packages.length} Packages!`);
        } else {
          showToast('ℹ️ No new external packages found.');
        }
      } catch (err) {
        showToast('❌ Error scanning: ' + err.message);
      }
    }

    function loadMyBotCode() {
      document.getElementById('scanCodeInput').value = "import requests\\nimport time\\nimport json\\nimport os\\nimport firebase_admin\\nfrom bs4 import BeautifulSoup\\nimport pyotp\\n";
      scanCodeDependencies();
    }

    function runSimMessage() {
      const input = document.getElementById('simInput');
      const text = input.value.trim();
      if (!text) return;
      const chat = document.getElementById('simulatorChat');
      chat.innerText += `\\nUser: ${text}`;
      input.value = '';

      let reply = "🤖 Received: " + text;
      if (text.startsWith('/start')) reply = "✨ Hello! Your Python Telegram Bot is running 24/7 on Vercel Serverless!";
      else if (text.startsWith('/ping')) reply = "🏓 Pong! Active and instant via Vercel Webhook ⚡";
      else if (text.startsWith('/status')) reply = "📊 Vercel Serverless: 100% Online, 0 Downtime!";
      else if (text.startsWith('/help')) reply = "📖 Commands: /start, /ping, /status, /echo";
      else if (text.startsWith('/echo')) reply = "🗣️ Echo: " + text.replace('/echo', '').trim();

      setTimeout(() => {
        chat.innerText += `\\nBot: ${reply}`;
        chat.scrollTop = chat.scrollHeight;
      }, 300);
    }

    function downloadFullProjectZip() {
      window.location.href = '/api/download_project';
      showToast('📦 Project zip downloading...');
    }

    setInterval(fetchLogs, 8000);
  </script>
</body>
</html>
"""

# If Flask is available, set up standard Flask routes
if FLASK_AVAILABLE:
    app = Flask(__name__)

    @app.route("/")
    def index():
        return Response(DASHBOARD_HTML, mimetype="text/html")

    @app.route("/api/status", methods=["GET"])
    def status():
        return jsonify({
            "status": "online",
            "runtime": "Vercel Python Serverless",
            "python_version": sys.version.split()[0],
            "uptime_seconds": int(time.time() - START_TIME),
            "logs": ACTIVITY_LOGS
        })

    @app.route("/api/webhook", methods=["GET", "POST"])
    def webhook():
        if request.method == "GET":
            return jsonify({"status": "Telegram Webhook Active", "method": "POST updates here"}), 200

        bot_token = os.environ.get("BOT_TOKEN") or request.args.get("token")
        data = request.get_json(silent=True) or {}
        
        # If token is not in environment, try header or body
        if not bot_token and "bot_token" in data:
            bot_token = data.get("bot_token")

        msg, code = handle_telegram_update(bot_token, data)
        return jsonify({"result": msg}), code

    @app.route("/api/set_webhook", methods=["POST"])
    def set_webhook():
        body = request.get_json(silent=True) or {}
        bot_token = body.get("bot_token")
        webhook_url = body.get("webhook_url")
        if not bot_token or not webhook_url:
            return jsonify({"ok": False, "description": "bot_token and webhook_url required"}), 400

        try:
            tg_res = requests.get(
                f"https://api.telegram.org/bot{bot_token}/setWebhook",
                params={"url": webhook_url},
                timeout=10
            )
            add_log("Set Webhook", f"Target: {webhook_url}", "success" if tg_res.json().get("ok") else "error")
            return jsonify(tg_res.json())
        except Exception as e:
            return jsonify({"ok": False, "description": str(e)}), 500

    @app.route("/api/webhook_info", methods=["POST"])
    def webhook_info():
        body = request.get_json(silent=True) or {}
        bot_token = body.get("bot_token")
        if not bot_token:
            return jsonify({"ok": False, "description": "bot_token required"}), 400

        try:
            tg_res = requests.get(f"https://api.telegram.org/bot{bot_token}/getWebhookInfo", timeout=10)
            return jsonify(tg_res.json())
        except Exception as e:
            return jsonify({"ok": False, "description": str(e)}), 500

    @app.route("/api/delete_webhook", methods=["POST"])
    def delete_webhook():
        body = request.get_json(silent=True) or {}
        bot_token = body.get("bot_token")
        if not bot_token:
            return jsonify({"ok": False, "description": "bot_token required"}), 400

        try:
            tg_res = requests.get(f"https://api.telegram.org/bot{bot_token}/deleteWebhook", timeout=10)
            add_log("Delete Webhook", "Webhook removed from Telegram", "info")
            return jsonify(tg_res.json())
        except Exception as e:
            return jsonify({"ok": False, "description": str(e)}), 500

    @app.route("/api/send_test", methods=["POST"])
    def send_test():
        body = request.get_json(silent=True) or {}
        bot_token = body.get("bot_token")
        chat_id = body.get("chat_id")
        text = body.get("text", "Hello from Vercel!")
        if not bot_token or not chat_id:
            return jsonify({"ok": False, "description": "bot_token and chat_id required"}), 400

        try:
            tg_res = requests.post(
                f"https://api.telegram.org/bot{bot_token}/sendMessage",
                json={"chat_id": chat_id, "text": text, "parse_mode": "HTML"},
                timeout=10
            )
            data = tg_res.json()
            add_log("Send Test", f"Sent to {chat_id}: {data.get('ok')}", "success" if data.get("ok") else "error")
            return jsonify(data)
        except Exception as e:
            return jsonify({"ok": False, "description": str(e)}), 500

    @app.route("/api/scan_requirements", methods=["POST"])
    def scan_requirements():
        body = request.get_json(silent=True) or {}
        code = body.get("code", "")
        packages = scan_python_code(code)
        return jsonify({"packages": packages})

    @app.route("/api/download_requirements", methods=["GET"])
    def download_requirements():
        content = "Flask>=3.0.0\nrequests>=2.31.0\nbeautifulsoup4>=4.12.0\npyotp>=2.9.0\n"
        return Response(
            content,
            mimetype="text/plain",
            headers={"Content-Disposition": "attachment;filename=requirements.txt"}
        )

    @app.route("/api/download_project", methods=["GET"])
    def download_project():
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
            zip_file.writestr("requirements.txt", "Flask>=3.0.0\nrequests>=2.31.0\nbeautifulsoup4>=4.12.0\npyotp>=2.9.0\n")
            zip_file.writestr("vercel.json", '{\n  "version": 2,\n  "builds": [\n    {\n      "src": "api/index.py",\n      "use": "@vercel/python"\n    }\n  ],\n  "routes": [\n    {\n      "src": "/(.*)",\n      "dest": "api/index.py"\n    }\n  ]\n}\n')
            
            # Read current api/index.py
            current_file = os.path.abspath(__file__)
            if os.path.exists(current_file):
                with open(current_file, "r") as f:
                    zip_file.writestr("api/index.py", f.read())

        zip_buffer.seek(0)
        return send_file(
            zip_buffer,
            mimetype="application/zip",
            as_attachment=True,
            download_name="telegram-vercel-bot.zip"
        )

else:
    # Pure standard-library WSGI fallback when Flask is not yet installed in local environment
    def app(environ, start_response):
        path = environ.get('PATH_INFO', '/')
        method = environ.get('REQUEST_METHOD', 'GET')
        
        if path == '/' or path == '/index.html':
            start_response('200 OK', [('Content-Type', 'text/html; charset=utf-8')])
            return [DASHBOARD_HTML.encode('utf-8')]
            
        if path == '/api/status':
            res = json.dumps({
                "status": "online",
                "runtime": "Local Python Standard Server (WSGI)",
                "python_version": sys.version.split()[0],
                "uptime_seconds": int(time.time() - START_TIME),
                "logs": ACTIVITY_LOGS
            })
            start_response('200 OK', [('Content-Type', 'application/json')])
            return [res.encode('utf-8')]

        if path == '/api/download_requirements':
            content = "Flask>=3.0.0\nrequests>=2.31.0\nbeautifulsoup4>=4.12.0\npyotp>=2.9.0\n"
            start_response('200 OK', [
                ('Content-Type', 'text/plain'),
                ('Content-Disposition', 'attachment; filename=requirements.txt')
            ])
            return [content.encode('utf-8')]

        if path == '/api/download_project':
            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
                zip_file.writestr("requirements.txt", "Flask>=3.0.0\nrequests>=2.31.0\nbeautifulsoup4>=4.12.0\npyotp>=2.9.0\n")
                zip_file.writestr("vercel.json", '{\n  "version": 2,\n  "builds": [\n    {\n      "src": "api/index.py",\n      "use": "@vercel/python"\n    }\n  ],\n  "routes": [\n    {\n      "src": "/(.*)",\n      "dest": "api/index.py"\n    }\n  ]\n}\n')
                current_file = os.path.abspath(__file__)
                if os.path.exists(current_file):
                    with open(current_file, "r") as f:
                        zip_file.writestr("api/index.py", f.read())
            zip_data = zip_buffer.getvalue()
            start_response('200 OK', [
                ('Content-Type', 'application/zip'),
                ('Content-Disposition', 'attachment; filename=telegram-vercel-bot.zip')
            ])
            return [zip_data]

        # Read JSON body for POST requests
        body = {}
        try:
            content_length = int(environ.get('CONTENT_LENGTH', 0) or 0)
            if content_length > 0:
                raw_body = environ['wsgi.input'].read(content_length)
                body = json.loads(raw_body.decode('utf-8'))
        except Exception:
            body = {}

        if path == '/api/scan_requirements' and method == 'POST':
            code = body.get('code', '')
            packages = scan_python_code(code)
            res = json.dumps({"packages": packages})
            start_response('200 OK', [('Content-Type', 'application/json')])
            return [res.encode('utf-8')]

        if path == '/api/set_webhook' and method == 'POST':
            bot_token = body.get('bot_token')
            webhook_url = body.get('webhook_url')
            if not bot_token or not webhook_url:
                start_response('400 Bad Request', [('Content-Type', 'application/json')])
                return [json.dumps({"ok": False, "description": "bot_token and webhook_url required"}).encode('utf-8')]
            try:
                tg_res = requests.get(f"https://api.telegram.org/bot{bot_token}/setWebhook", params={"url": webhook_url}, timeout=10)
                add_log("Set Webhook", f"Target: {webhook_url}", "success" if tg_res.json().get("ok") else "error")
                start_response('200 OK', [('Content-Type', 'application/json')])
                return [tg_res.text.encode('utf-8')]
            except Exception as e:
                start_response('500 Internal Error', [('Content-Type', 'application/json')])
                return [json.dumps({"ok": False, "description": str(e)}).encode('utf-8')]

        if path == '/api/webhook_info' and method == 'POST':
            bot_token = body.get('bot_token')
            if not bot_token:
                start_response('400 Bad Request', [('Content-Type', 'application/json')])
                return [json.dumps({"ok": False, "description": "bot_token required"}).encode('utf-8')]
            try:
                tg_res = requests.get(f"https://api.telegram.org/bot{bot_token}/getWebhookInfo", timeout=10)
                start_response('200 OK', [('Content-Type', 'application/json')])
                return [tg_res.text.encode('utf-8')]
            except Exception as e:
                start_response('500 Internal Error', [('Content-Type', 'application/json')])
                return [json.dumps({"ok": False, "description": str(e)}).encode('utf-8')]

        if path == '/api/delete_webhook' and method == 'POST':
            bot_token = body.get('bot_token')
            if not bot_token:
                start_response('400 Bad Request', [('Content-Type', 'application/json')])
                return [json.dumps({"ok": False, "description": "bot_token required"}).encode('utf-8')]
            try:
                tg_res = requests.get(f"https://api.telegram.org/bot{bot_token}/deleteWebhook", timeout=10)
                add_log("Delete Webhook", "Webhook removed from Telegram", "info")
                start_response('200 OK', [('Content-Type', 'application/json')])
                return [tg_res.text.encode('utf-8')]
            except Exception as e:
                start_response('500 Internal Error', [('Content-Type', 'application/json')])
                return [json.dumps({"ok": False, "description": str(e)}).encode('utf-8')]

        if path == '/api/send_test' and method == 'POST':
            bot_token = body.get('bot_token')
            chat_id = body.get('chat_id')
            text = body.get('text', 'Hello from Vercel!')
            if not bot_token or not chat_id:
                start_response('400 Bad Request', [('Content-Type', 'application/json')])
                return [json.dumps({"ok": False, "description": "bot_token and chat_id required"}).encode('utf-8')]
            try:
                tg_res = requests.post(f"https://api.telegram.org/bot{bot_token}/sendMessage", json={"chat_id": chat_id, "text": text, "parse_mode": "HTML"}, timeout=10)
                add_log("Send Test", f"Sent to {chat_id}: {tg_res.json().get('ok')}", "success" if tg_res.json().get('ok') else "error")
                start_response('200 OK', [('Content-Type', 'application/json')])
                return [tg_res.text.encode('utf-8')]
            except Exception as e:
                start_response('500 Internal Error', [('Content-Type', 'application/json')])
                return [json.dumps({"ok": False, "description": str(e)}).encode('utf-8')]

        if path == '/api/webhook':
            if method == 'GET':
                start_response('200 OK', [('Content-Type', 'application/json')])
                return [json.dumps({"status": "Telegram Webhook Active", "method": "POST updates here"}).encode('utf-8')]
            query = parse_qs(environ.get('QUERY_STRING', ''))
            bot_token = os.environ.get("BOT_TOKEN") or (query.get('token', [None])[0]) or body.get("bot_token")
            msg, code = handle_telegram_update(bot_token, body)
            status_str = f"{code} OK" if code == 200 else f"{code} Error"
            start_response(status_str, [('Content-Type', 'application/json')])
            return [json.dumps({"result": msg}).encode('utf-8')]

        # Fallback 404
        start_response('404 Not Found', [('Content-Type', 'text/plain')])
        return [b"Not Found"]


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    if FLASK_AVAILABLE:
        print(f"🚀 Starting Flask Server on http://localhost:{port}")
        app.run(host="0.0.0.0", port=port, debug=False)
    else:
        from wsgiref.simple_server import make_server
        print(f"⚡ Starting Standard WSGI Server on http://localhost:{port}")
        server = make_server("0.0.0.0", port, app)
        server.serve_forever()
